import { NgModule } from '@angular/core';


import {BrowserModule} from '@angular/platform-browser'
import { FormsModule } from "@angular/forms";
import {LayoutModule} from './layout/layout.module'
import { HeaderComponent } from './layout/components/header/header.component';
import { FooterComponent } from './layout/components/footer/footer.component';
import { BlockComponent } from './layout/components/block/block.component';
import { AppComponent } from './components/app/app.component';



@NgModule({
  declarations: [AppComponent],
  imports: [
    BrowserModule,
    LayoutModule,
    FormsModule
  ],
  bootstrap:[AppComponent]
})
export class AppModule { }

import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {UtilityModule} from '../utility/utility.module'
import { HeaderComponent } from './components/header/header.component';
import { FooterComponent } from './components/footer/footer.component';
import { BlockComponent } from './components/block/block.component';


@NgModule({
  declarations: [HeaderComponent, FooterComponent, BlockComponent],
  imports: [
    CommonModule,UtilityModule
  ],
  exports:[HeaderComponent,FooterComponent,BlockComponent]
})
export class LayoutModule { }

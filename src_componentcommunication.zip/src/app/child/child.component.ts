import { Component, OnInit, Input, EventEmitter, Output } from '@angular/core';

@Component({
  selector: 'app-child',
  templateUrl: './child.component.html',
  styleUrls: ['./child.component.css']
})
export class ChildComponent implements OnInit {

  @Input()
  hostContent:string;

  @Output()
  onChildTextChanged=new EventEmitter<string>();

  constructor() { }

  ngOnInit(): void {
  }

  onChildTextBoxEdit(data:string){

    //Raise An Event
    this.onChildTextChanged.emit(data);

  }

}

import { Component, OnInit ,EventEmitter,Output} from '@angular/core';

@Component({
  selector: 'app-bug-seacrh-bar',
  templateUrl: './bug-seacrh-bar.component.html',
  styleUrls: ['./bug-seacrh-bar.component.css']
})
export class BugSeacrhBarComponent implements OnInit {

  constructor() { }

  @Output()
  onSearchKeyChanged=new EventEmitter<string>();

  ngOnInit(): void {
  }

  onSearch(searchKey){

    this.onSearchKeyChanged.emit(searchKey);

  }

}

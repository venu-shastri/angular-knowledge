import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule} from '@angular/forms'

import { AppComponent } from './app.component';
import { HostComponent } from './host/host.component';
import { ChildComponent } from './child/child.component';
import { BugSeacrhBarComponent } from './bug-seacrh-bar/bug-seacrh-bar.component';
import { BugSearchPanellComponent } from './bug-search-panell/bug-search-panell.component';
import { BugDetailsComponent } from './bug-details/bug-details.component';
import {BugSearchService} from './services/bugSearch.service'

@NgModule({
  declarations: [
    AppComponent,
    HostComponent,
    ChildComponent,
    BugSeacrhBarComponent,
    BugSearchPanellComponent,
    BugDetailsComponent
  ],
  imports: [
    BrowserModule,
    FormsModule
  ],
  providers: [{provide:BugSearchService,useClass:BugSearchService}],
  bootstrap: [AppComponent]
})
export class AppModule { }

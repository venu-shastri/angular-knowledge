export class BugModel{

  BugId:string="";
  BugDescription:string="";
  BugStatus:string="";
  BugOwner:string="";

  constructor(){

  }

}

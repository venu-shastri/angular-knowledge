import {BugModel} from '../models/bug.model'
export class BugSearchService{

  searchBugById(bugId):BugModel{

    let bug=new BugModel();
    bug.BugId=bugId;
    bug.BugStatus="OPEN";
    bug.BugDescription=`Bug Description for ${bugId}`;
    bug.BugOwner="Tom";
    return bug;

  }

}

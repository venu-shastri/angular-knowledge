import { Component, OnInit, Input, AfterViewInit } from '@angular/core';
import { BugModel } from '../models/bug.model';

@Component({
  selector: 'app-bug-details',
  templateUrl: './bug-details.component.html',
  styleUrls: ['./bug-details.component.css']
})
export class BugDetailsComponent implements OnInit ,AfterViewInit {
  @Input()
  bug:BugModel
  constructor() {

      console.log("Instantiated");


   }
  ngOnInit(): void {

    this.bug=new  BugModel();
    console.log("oninit");

  }
  ngAfterViewInit(){
    console.log("After View Init");
  }

}

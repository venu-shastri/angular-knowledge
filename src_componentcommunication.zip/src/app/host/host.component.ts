import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-host',
  templateUrl: './host.component.html',
  styleUrls: ['./host.component.css']
})
export class HostComponent implements OnInit {

  message:string;
  childMessage:string;
  constructor() {
  this.message="";
 }

  ngOnInit(): void {
  }
  onChildTextChanged_Handler(data){

    this.childMessage=data;
  }

}

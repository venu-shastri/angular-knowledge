import { Component, OnInit } from '@angular/core';
import {BugModel} from '../models/bug.model'
import {BugSearchService} from '../services/bugSearch.service'
@Component({
  selector: 'app-bug-search-panell',
  templateUrl: './bug-search-panell.component.html',
  styleUrls: ['./bug-search-panell.component.css']
})
export class BugSearchPanellComponent implements OnInit {
  searchService:BugSearchService;
  selectedBug:BugModel;

  constructor(searchService:BugSearchService) {

    this.searchService=searchService;
   }

  ngOnInit(): void {
  }
  onSearchKeyChanged_Handler(key)
  {
    console.log(key);
    this.selectedBug=this.searchService.searchBugById(key);


  }

}

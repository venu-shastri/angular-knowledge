import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BugSearchPanellComponent } from './bug-search-panell.component';

describe('BugSearchPanellComponent', () => {
  let component: BugSearchPanellComponent;
  let fixture: ComponentFixture<BugSearchPanellComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BugSearchPanellComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BugSearchPanellComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

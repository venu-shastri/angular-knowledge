import {IBService} from './ib.service'
export class NewbService extends IBService{

  constructor(){
    super();
    console.log("NewBService Instantiated");
  }

  task(){
    
  }
}

import { Component, Inject } from '@angular/core';
import {AService} from './a.service'
import { CService } from './c.service';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {

  constructor(obj:AService,newObj:CService,@Inject("logService")log:CService){

  }
  title = 'didemo';
}

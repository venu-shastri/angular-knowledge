import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { AService } from './a.service';
import { BService } from './b.service';
import { CService } from './c.service';
import { NewbService} from './newB.service'
import { IBService } from './ib.service';

@NgModule({
  declarations: [
    AppComponent
  ],
  imports: [
    BrowserModule
  ],
  providers: [
    {provide:AService,useClass:AService},
    {provide:IBService,useFactory:function(){
      return[new BService(),new NewbService()]}},
    {provide:CService,useClass:CService},
    {provide:'connectionString',useValue:"http://www.pic.com:1234/HDP/testservice"},
    {provide:'serverconfiguration',useValue:{name:'test',port:1234}},
    {provide:'logService',useFactory:function(){ return new CService();}}

  ],
  bootstrap: [AppComponent]
})
export class AppModule { }

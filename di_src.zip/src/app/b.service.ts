import { Injectable, Inject } from '@angular/core';
import { CService } from './c.service';
import {IBService} from './ib.service'


@Injectable()
export class BService extends IBService{

  constructor() {
    super();
     console.log("Service B Instantiated");
    }

  task():void{}
}

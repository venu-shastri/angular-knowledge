//interface or Pure Abstract Class
export abstract class IBService{
  public abstract task():void;
}

export class CService{

  constructor() { console.log("Service C Instantiated");}
}

import {Inject,Injectable, InjectionToken} from '@angular/core'
import { IBService } from './ib.service';


@Injectable()
export class AService{

  constructor(@Inject(IBService)obj:Array<IBService>) {
     console.log("Service A Instantiated");
     //obj.task();
    }
}

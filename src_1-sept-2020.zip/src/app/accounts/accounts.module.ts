import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {FormsModule} from '@angular/forms'
import { LoginComponent } from './components/login/login.component';
import { SignupComponent } from './components/signup/signup.component';
import { ChangepasswordComponent } from './components/changepassword/changepassword.component';
import { PasswordrecoveryComponent } from './components/passwordrecovery/passwordrecovery.component';



@NgModule({
  declarations: [LoginComponent, SignupComponent, ChangepasswordComponent, PasswordrecoveryComponent],
  imports: [
    CommonModule,
    FormsModule
  ],
  exports:[LoginComponent,SignupComponent]
})
export class AccountsModule { }

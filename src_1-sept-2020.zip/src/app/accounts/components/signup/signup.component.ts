import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {

  userName:string;
  password:string;
  retypePassword:string;
  email:string;
  errorMessage:string;

  constructor() {
      this.reset();
    }

  ngOnInit(): void {
  }

  signup(){

    console.log(`UserName ${this.userName} Password ${this.password} Email ${this.email}`);
  }

  reset(){
    this.userName="";
    this.password="";
    this.retypePassword="";
    this.email="";
  }
}

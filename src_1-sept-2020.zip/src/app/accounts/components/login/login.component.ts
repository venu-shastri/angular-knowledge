import { Component, OnInit } from '@angular/core';
import {ConsoleLoggerService} from '../../../services/consoleLogger.service'

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  userName:string;
  password:string;
  errorMessage:string;
  _logger:ConsoleLoggerService;

  constructor(logger:ConsoleLoggerService) {

    this.userName="";
    this.password="";
    this._logger=logger;
   }

  ngOnInit(): void {
  }

  login():void{

    this._logger.write("login button clicked");
    if(this.userName=="admin" && this.password=="admin@123"){
        this._logger.write("Login Sucessfull");
        this.errorMessage="";
    }
    else{
        this.errorMessage="Invalid UserName and Password";

    }
  }

  onUserNameEdit(userName){
    this.userName=userName;
    this._logger.write("User Name " +this.userName );

  }
  onPasswordEdit(password){
this.password=password;
this._logger.write("Password " + this.password);
  }

  reset(){
    this.userName="";
    this.password="";
    this.errorMessage="";
  }

}

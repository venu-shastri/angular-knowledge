import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-passwordrecovery',
  templateUrl: './passwordrecovery.component.html',
  styleUrls: ['./passwordrecovery.component.css']
})
export class PasswordrecoveryComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

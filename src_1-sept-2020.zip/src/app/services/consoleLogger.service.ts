export class ConsoleLoggerService{

  write(msg:string):void{

    console.log(msg);
  }
}

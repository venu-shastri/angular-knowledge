import { NgModule } from '@angular/core';
import {BrowserModule} from '@angular/platform-browser'
import {LayoutModule} from './layout/layout.module'
import {UtilityModule} from './utility/utility.module'
import {AccountsModule} from  './accounts/accounts.module'
import { AppComponent } from './components/app/app.component';
import { LoginComponent } from './accounts/components/login/login.component';



@NgModule({
  declarations: [AppComponent],
  imports: [BrowserModule,LayoutModule,UtilityModule,AccountsModule],
  bootstrap:[AppComponent]
})
export class AppModule { }

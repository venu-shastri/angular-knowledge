import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { HeaderComponent } from './components/header/header.component';
import { FooterComponent } from './components/footer/footer.component';
import { BlockComponent } from './components/block/block.component';


@NgModule({
  declarations: [HeaderComponent, FooterComponent, BlockComponent],
  imports: [
    CommonModule
  ],
  exports:[HeaderComponent,FooterComponent,BlockComponent]
})
export class LayoutModule { }
